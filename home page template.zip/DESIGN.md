# Design System Document: The Definitive Ledger

## 1. Overview & Creative North Star
### The Creative North Star: "The Digital Archivist"
This design system is not a mere utility; it is a digital institution. It is designed to feel like a permanent, high-end editorial record—think of the heavy-stock paper of a century-old financial journal or the precise digital interfaces used by top-tier data journalists. 

The system moves away from the "bubbly" trends of modern SaaS. By utilizing **intentional asymmetry**, **sharp 0px corners**, and **high-contrast editorial typography**, we create an atmosphere of permanence. We break the rigid, repetitive grid by allowing display typography to breathe and utilizing "The Record" (our high-contrast serif) to anchor the user’s gaze. The interface is not "pasted" together; it is curated.

---

## 2. Colors: The Palette of Precision
Our color strategy is built on the contrast between **Granite** (the weight of authority) and **Snow** (the clarity of truth), with **Heritage Red** acting as the definitive stamp of importance.

### The Palette
*   **Primary (Heritage Red):** `#820012`. Used exclusively for critical data points, primary calls to action, and "Verified" statuses. It is a color of record, not a color of alarm.
*   **Neutral (Granite & Snow):** 
    *   `surface_container_lowest`: `#ffffff` (The pure white of a fresh page).
    *   `on_surface`: `#161c24` (The deep, blue-grey ink of 'Granite').
    *   `surface`: `#f8f9ff` (A crisp, professional 'Snow' wash).

### The "No-Line" Rule
To maintain a premium editorial feel, prohibit the use of 1px solid borders for architectural sectioning. Large sections of content must be defined through **background color shifts** (e.g., a `surface-container-low` content block sitting on a `surface` background). This creates a "sheet-on-sheet" aesthetic rather than a "box-inside-box" feel.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of fine paper. 
*   **Base:** `surface`
*   **Primary Content Area:** `surface_container_low`
*   **Floating Elements/Cards:** `surface_container_lowest`
This nesting creates depth through value rather than shadows, reinforcing a sense of structural integrity.

### Signature Textures & Gradients
For Hero sections or primary CTAs, use a subtle linear gradient transitioning from `primary` (#820012) to `primary_container` (#a61d24) at a 15-degree angle. This provides a "lathe-turned" metallic finish that flat colors cannot replicate.

---

## 3. Typography: The Voice of 'The Record'
Typography is our most powerful tool for conveying authority. We use a "Double-Voice" system.

### The Editorial Voice (Newsreader)
*   **Role:** Display, Headlines, and Pull-quotes.
*   **Vibe:** Archival, prestigious, and undeniable. 
*   **Usage:** Large `display-lg` headlines should have slightly tightened letter-spacing (-0.02em) to feel like a printed masthead.

### The Functional Voice (Public Sans)
*   **Role:** UI Elements, Data Labels, Body Copy, and Navigation.
*   **Vibe:** Swiss-inspired, neutral, and obsessively legible.
*   **Usage:** Use `label-md` for technical data (e.g., VIN numbers) in all-caps with +0.05em tracking to evoke a sense of precision engineering.

---

## 4. Elevation & Depth: Tonal Layering
In this design system, shadows are a last resort. We convey hierarchy through the **Layering Principle**.

*   **Tonal Stacking:** Depth is achieved by placing a `surface-container-lowest` card on a `surface-container-low` section. This creates a natural, soft lift.
*   **Ambient Shadows:** If an element must float (e.g., a dropdown), use an ultra-diffused shadow: `Y: 8px, Blur: 24px, Color: on_surface @ 6%`. It should feel like a soft glow of light, not a dark smudge.
*   **The "Ghost Border" Fallback:** For data tables or input fields where containment is functionally required, use a "Ghost Border": the `outline_variant` token at **15% opacity**. Never use 100% opaque borders for decorative purposes.
*   **Sharpness:** All elements use `0px` (none) rounding. This sharp-edge philosophy communicates that our data is "cut" with precision and has no room for "soft" interpretations.

---

## 5. Components: The Building Blocks of Truth

### Buttons
*   **Primary:** Sharp corners, `primary` background, `on_primary` text. High-contrast, definitive.
*   **Secondary:** `surface_container_highest` background with a `Ghost Border`.
*   **Interaction:** On hover, primary buttons shift to `primary_container`. No rounded corners.

### Inputs & Text Fields
*   **Style:** Minimalist. A simple 1px `Ghost Border` on the bottom, or a full Ghost Border box if necessary. 
*   **Focus State:** The border transitions to `primary` (Heritage Red) at 100% opacity. Label moves to `label-sm` above the field.

### Cards & Data Modules
*   **Forbid Dividers:** Never use horizontal lines to separate list items. Use **Vertical White Space** (16px, 24px, or 32px from the scale) or subtle tonal shifts between `surface_container_low` and `surface_container_high`.
*   **The Masthead Card:** A specific component for Vehicle Identity. Uses a `primary` top-border (2px) to denote it as the "Source of Truth."

### Chips & Tags
*   **Data Journalism Style:** Rectangular, `0px` radius. Use `surface_container_high` for neutral data and `error_container` with `on_error_container` text for "Critical Alerts."

---

## 6. Do's and Don'ts

### Do:
*   **Do** use extreme whitespace to separate major content themes.
*   **Do** lean into the "Asymmetric Balance"—place a large serif headline off-center to create an editorial layout.
*   **Do** use `Heritage Red` for numerical data that indicates a change in status or a critical finding.

### Don't:
*   **Don't** use a single pixel of border-radius. Every corner must be a perfect 90-degree angle.
*   **Don't** use generic blue for links. Use `tertiary` (#00435d) for a more sophisticated, "ink-like" blue-grey.
*   **Don't** use heavy "drop shadows." If it doesn't look like it's made of stacked paper, it’s too heavy.
*   **Don't** use icons without labels. In an authoritative system, clarity is more important than "minimalist" mystery.

---
*Director's Note: Remember, we are not just building an interface. We are building a legacy document for every vehicle in Canada. Every pixel must feel intentional, and every margin must feel earned.*